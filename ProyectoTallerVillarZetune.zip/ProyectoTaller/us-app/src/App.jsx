import './App.css';
import Places from './Components/places'
import React, { createContext, useState, useContext } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Signin from './Components/signin';
import PublicMenu from './Components/publicMenu';
import PrivateMenu from './Components/privateMenu';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/Login';
import Founds from './Components/founds';
import Inicio from './Components/Inicio';
import Añadir from './Components/Add';
import AñadirObjeto from './Components/AddF';

const CounterContext = createContext();

export const useCounter = () => useContext(CounterContext);
const App = ({children}) => {
  const [isLogOn, setLogOn] = useState(false);
  return (
    <CounterContext.Provider value={{ isLogOn, setLogOn}}>
        <BrowserRouter>
      { isLogOn ? <PrivateMenu /> : <PublicMenu /> }
        <Routes>
          <Route path="/signin" element={<Signin />} />
          <Route path="/places" element={<Places />} />
          <Route path="/founds" element={<Founds />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Inicio" element={<Inicio />} />
          <Route path="/Add" element={<Añadir />} />
          <Route path="/AddF" element={<AñadirObjeto />} />
        </Routes>
      </BrowserRouter>
    </CounterContext.Provider>
  );
}

export default App;



