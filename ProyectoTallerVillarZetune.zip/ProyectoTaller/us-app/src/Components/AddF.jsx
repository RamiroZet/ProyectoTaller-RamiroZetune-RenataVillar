import React, { useState, useEffect } from 'react';
import { Form, Button } from 'react-bootstrap';

const AddF = () => {
   
    const [formData, setFormData] = useState({
        
        placeId: '',
        userId:'1' ,
        name: '',
        description: '',
        date: '',
        images : [{url:''}],
        type: '',
        region: '',
        city: '',
        country: '',
        
            
        
    });
 
    const handleChange = (e) => {
        let { name, value } = e.target;
        if(name == 'images'){
          let image = [{url: value}];
          value = image;
        }
          setFormData(prevState => ({
            ...prevState,
            [name]: value
          }));
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('https://history-hunters-morning-api.onrender.com/places/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
              console.log('Agregado con exito')
              setFormData({
                placeId: '',
                userId:'1' ,
                name: '',
                description: '',
                date: '',
                images : [{url:''}],
                type: '',
                region: '',
                city: '',
                country: '',
                
              });
            } else {
                
                    console.log('Datos Incorrectos');
                }
            }
         catch (error) {
            console.error('Error al ingresar lugar:', error);
        }
    };
  return (
    <div className="container">
    <div className="row justify-content-center mt-5">
        <div className="col-md-6">
            <div className="card">
                <div className="card-header">Ingresar Objeto</div>
                <div className="card-body">
                    <Form onSubmit={handleSubmit}>
                        <Form.Group >
                            <Form.Label>Nombre</Form.Label>
                            <Form.Control type="text" name="name" value={formData.name} onChange={handleChange} required />
                        </Form.Group>

                        <Form.Group>
                            <Form.Label>Descripción</Form.Label>
                            <Form.Control type="text" name="description" value={formData.description} onChange={handleChange} required />
                        </Form.Group>

                        <Form.Group>
                            <Form.Label>Fecha</Form.Label>
                            <Form.Control type="date" name="date" value={formData.date} onChange={handleChange} required />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Imagen</Form.Label>
                            <Form.Control type="text" name="images" value={formData.images[0].url} onChange={handleChange} required />
                        </Form.Group>
                       
                        <Form.Group>
                            <Form.Label>Tipo</Form.Label>
                            <Form.Control type="text" name="type" value={formData.type} onChange={handleChange} required />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Region</Form.Label>
                            <Form.Control type="text" name="region" value={formData.region} onChange={handleChange} required />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Ciudad</Form.Label>
                            <Form.Control type="text" name="city" value={formData.city} onChange={handleChange} required />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Pais</Form.Label>
                            <Form.Control type="text" name="country" value={formData.country} onChange={handleChange} required />
                        </Form.Group>
                     
                        
                        <Button variant="primary" type="submit">
                            AñadirObjeto
                        </Button>
                    </Form>
                </div>
            </div>
        </div>
    </div>
</div>
)}


export default AddF;
