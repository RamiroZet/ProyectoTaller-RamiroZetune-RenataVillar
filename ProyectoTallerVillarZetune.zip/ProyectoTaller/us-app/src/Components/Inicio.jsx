const Inicio = () => {
    return(<h1> Anduvo</h1> )

}
export default Inicio;
