import React, { useState } from 'react';
import { Link, useNavigate  } from 'react-router-dom';
import { Form, Button } from 'react-bootstrap';
import { useCounter } from '../App';


const Login = () => {

    const { setLogOn } = useCounter();

    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });


    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('https://history-hunters-morning-api.onrender.com/users/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                setLogOn(true);
                navigate('/places'); // Redirigimos a la página de Places
            } else {
                if (response.status === 400) {
                    console.log('Datos Incorrectos');
                } else {
                    console.error('Error al ingresar');
                }
            }
        } catch (error) {
            console.error('Error al ingresar usuario:', error);
        }
    };

    return (
        <div className="container">
            <div className="row justify-content-center mt-5">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">Ingresar Usuario</div>
                        <div className="card-body">
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="email">
                                    <Form.Label>Correo Electrónico</Form.Label>
                                    <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} required />
                                </Form.Group>

                                <Form.Group controlId="password">
                                    <Form.Label>Contraseña</Form.Label>
                                    <Form.Control type="password" name="password" value={formData.password} onChange={handleChange} required />
                                </Form.Group>

                                <Button variant="primary" type="submit">
                                    Ingresar
                                </Button>

                                <Link to="/signin">¿No tienes una cuenta? Regístrate aquí</Link>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;
