import React, { useState, useEffect } from 'react';
import { CardPlace } from './cardPlace';

const Places = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        const url = 'https://history-hunters-morning-api.onrender.com/places';
        fetch(url)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error('Error al obtener los datos');
            })
            .then(data => {
                setData(data.data);
            })
            .catch(error => {
                console.error('Error en la solicitud:', error);
            });
    }, []);

    return (
        <div className='card-container'>
            {data.map((place, index) => (
                <CardPlace 
                    key={index}
                    imageUrl={place.images}
                    name={place.name}
                    description={place.description}
                />
            ))}
        </div>
    );
};

export default Places;
