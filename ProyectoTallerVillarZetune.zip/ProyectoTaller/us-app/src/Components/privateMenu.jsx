import React from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import { useCounter } from '../App';
import { Link } from 'react-router-dom';

const PrivateMenu = () => {
  const { setLogOn } = useCounter();

  const handleLogout = () => {
    setLogOn(false); // Aquí actualizamos el estado para cerrar la sesión
  };
  return (
    <Navbar bg="light" expand="lg">
      <Navbar.Brand as={Link} to="/places">Menu privado</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
        <LinkContainer to="/places">
            <Nav.Link >Sitios</Nav.Link>
          </LinkContainer> 
            <LinkContainer to="/Add">
            <Nav.Link>AñadirSitios</Nav.Link>
          </LinkContainer>
          <LinkContainer to="/founds">
            <Nav.Link >Objetos</Nav.Link>
          </LinkContainer> 
          <LinkContainer to="/AddF">
            <Nav.Link>AñadirObjetos</Nav.Link>
          </LinkContainer>
          <LinkContainer to="/Login">
            <Nav.Link onClick={handleLogout}>Salir</Nav.Link>
          </LinkContainer> 
          
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}

export default PrivateMenu;
