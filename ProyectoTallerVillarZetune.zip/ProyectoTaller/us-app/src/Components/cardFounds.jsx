import React, { useState } from 'react';
import Card from 'react-bootstrap/Card';
import Carousel from 'react-bootstrap/Carousel';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import '../Components/styles/places.css';

export const CardFounds = (props) => {
    const [comment, setComment] = useState('');
    const [rating, setRating] = useState(1); // Estado para el rating, inicializado en 1

    const handleChangeComment = (e) => {
        setComment(e.target.value);
    };

    const handleChangeRating = (e) => {
        setRating(parseInt(e.target.value)); // Convertir el valor del rating a un número entero
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = {
            userId: 1, // Reemplaza el valor según el userId del usuario actual
            placeId: 1, // Reemplaza el valor según el placeId del lugar
            foundId: 1, // Reemplaza el valor según el foundId del evento encontrado
            review: comment,
            rating: rating
        };
        try {
            const response = await fetch('https://history-hunters-morning-api.onrender.com/reviews/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                console.log('Reseña agregada exitosamente');
                // Puedes hacer algo después de agregar la reseña, como redirigir a otra página
            } else {
                console.error('Error al agregar la reseña');
            }
        } catch (error) {
            console.error('Error al agregar la reseña:', error);
        }
    };

    return (
        <Card className="card-item">
            <div className="card-image-container">
                {props.imageUrl && props.imageUrl.length > 0 ? (
                    props.imageUrl.length > 1 ? (
                        <Carousel style={{ height: '15rem' }}>
                            {props.imageUrl.map((image, index) => (
                                <Carousel.Item key={index}>
                                    <img
                                        className="d-block w-100"
                                        src={image.url}
                                        alt={`Slide ${index}`}
                                        style={{ maxHeight: '15rem', objectFit: 'cover' }}
                                    />
                                </Carousel.Item>
                            ))}
                        </Carousel>
                    ) : (
                        <Card.Img
                            variant="top"
                            src={props.imageUrl[0].url}
                            alt={props.name}
                            style={{ maxHeight: '15rem', objectFit: 'cover' }}
                        />
                    )
                ) : (
                    <p>No hay imágenes disponibles</p>
                )}
            </div>
            <Card.Body className="card-text-container">
                <div>
                    <Card.Title> <span style={{ fontWeight: 'bold' }}>Nombre:</span> {props.name}</Card.Title>
                    <Card.Text> <span style={{ fontWeight: 'bold' }}>Descripción:</span> {props.description}</Card.Text>
                </div>
                <Form onSubmit={handleSubmit}>
                    <Form.Group controlId="comment">
                        <Form.Control
                            as="textarea"
                            rows={3}
                            value={comment}
                            onChange={handleChangeComment}
                            placeholder="Escribe tu comentario aquí..."
                            required
                        />
                    </Form.Group>
                    <Form.Group controlId="rating">
                        <Form.Label>Valoración:</Form.Label>
                        <Form.Control as="select" value={rating} onChange={handleChangeRating}>
                            {[1, 2, 3, 4, 5].map((value) => (
                                <option key={value} value={value}>{value}</option>
                            ))}
                        </Form.Control>
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Enviar Comentario y Valoración
                    </Button>
                </Form>
            </Card.Body>
        </Card>
    );
}
