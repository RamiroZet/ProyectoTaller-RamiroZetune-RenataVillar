import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { Link, useNavigate  } from 'react-router-dom';

const Signin = () => {
    const [formData, setFormData] = useState({
        name: '',
        lastName: '',
        address: '',
        email: '',
        password: ''
    });
    const navigate = useNavigate();
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('https://history-hunters-morning-api.onrender.com/users/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                navigate('/Login')
                console.log('Login exitoso.');
            } else {
                console.error('Error al ingresar');
            }
        } catch (error) {
            console.error('Error al ingresar usuario:', error);
        }
    };

    return (
        <div className="container">
            <div className="row justify-content-center mt-5">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">Registro de Usuario</div>
                        <div className="card-body">
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="name">
                                    <Form.Label>Nombre</Form.Label>
                                    <Form.Control type="text" name="name" value={formData.name} onChange={handleChange} required />
                                </Form.Group>

                                <Form.Group controlId="lastName">
                                    <Form.Label>Apellido</Form.Label>
                                    <Form.Control type="text" name="lastName" value={formData.lastName} onChange={handleChange} required />
                                </Form.Group>

                                <Form.Group controlId="address">
                                    <Form.Label>Dirección</Form.Label>
                                    <Form.Control type="text" name="address" value={formData.address} onChange={handleChange} required />
                                </Form.Group>

                                <Form.Group controlId="email">
                                    <Form.Label>Correo Electrónico</Form.Label>
                                    <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} required />
                                </Form.Group>

                                <Form.Group controlId="password">
                                    <Form.Label>Contraseña</Form.Label>
                                    <Form.Control type="password" name="password" value={formData.password} onChange={handleChange} required />
                                </Form.Group>

                                <Button variant="primary" type="submit">
                                    Registrarse
                                </Button>

                                <Link to="/">Iniciar Sesion</Link>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Signin;
