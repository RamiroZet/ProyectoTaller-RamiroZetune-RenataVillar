import React, { useState, useEffect } from 'react';
import { CardFounds } from './cardFounds';

const Founds = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        const url = 'https://history-hunters-morning-api.onrender.com/founds';
        fetch(url)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error('Error al obtener los datos');
            })
            .then(data => {
                setData(data.data);
            })
            .catch(error => {
                console.error('Error en la solicitud:', error);
            });
    }, []);

    return (
        <div className='card-container'>
            {data.map((founds, index) => (
                <CardFounds 
                    key={index}
                    imageUrl={founds.images}
                    name={founds.name}
                    description={founds.description}
                />
            ))}
        </div>
    );
};

export default Founds;
